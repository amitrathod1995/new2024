package com.edusol.product.service;

//import java.util.ArrayList;
//import java.util.List;
//import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.edusol.product.model.Product;
import com.edusol.product.repository.ProductRepository;
import com.google.gson.JsonObject;


@Service
public class ProductService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	ProductRepository productRepository;
	//List<Product> productList = new ArrayList<>();
	
	/*public Object getProducts() {
		
		//if(productList.isEmpty()) {
		//	return"No Product Found";
		//}

		return productRepository.findAll();
	}

	public Object addProduct(Product product) {
        productList.add(product);
		return "Product Added Successfully";
	}

	public Object updateProduct(Product product) {
	    boolean flag = false;
		
	   if(productList.isEmpty()) {
		   return "No Customer Found";
	    }
	   
	  for(Product pro:productList) {
		if(pro.getProductId()==product.getProductId()) {
		    productList.remove(pro);
		    productList.add(product);
		     
		       flag = true;
		      
		       break;
		}
    }
		 if(flag == false) { 
		 return "Product data is not available";  
		 }return"product updated Successfully";
    }

	public Object deleteProduct(int productId) {
		 boolean flag = false;
			
		  if(productList.isEmpty()) {
			 return "No Product Found";
		    }
			
		for(Product pro:productList) {
		  if(pro.getProductId() == productId) {
			 productList.remove(pro);
			flag = true;
			 break;
		   }
	   }
		
	      if(flag == false) {
			  
	    	  return"Product is not Available";
			    }
		      return"Product Deleted Successfully";
		}

	

	public Object getProduct(String Category) {
		
		if(productList.isEmpty()) {
			return"No Product Found";
		}
		 List<Product> products = productList.stream()
			     .filter(c->c.getProductCategory().equalsIgnoreCase(Category))
				 .collect(Collectors.toList());
				
			 if(productList.isEmpty()) {
				return "Product Not Found";
			    }
				return products;
	}

	public Object getProductPrice(float Price) {
		if(productList.isEmpty()) {
			return"No Product Found";
		}
		 List<Product> products = productList.stream()
			     .filter(c->c.getProductPrice()==(Price))
				 .collect(Collectors.toList());
				
			 if(productList.isEmpty()) {
				return "Product Not Found";
			    }
				return products;
	}



	public Object getProductPriceByRange(float min, float max) {
		if(productList.isEmpty()) {
			return"No Product Found";
		}
		List<Product> products = productList.stream()
			     .filter(c->c.getProductPrice()>= min && max >= c.getProductPrice())
				 .collect(Collectors.toList());
				
			 if(productList.isEmpty()) {
				return "Product Not Found";
			    }
			 return products;
	}

	public Object getProductPriceByRangeAndCategory(float min, float max, String category) {
		if(productList.isEmpty()) {
			return"No Product Found";
		}
		List<Product> products = productList.stream()
			     .filter(c->c.getProductPrice()>= min && c.getProductPrice()<= max).filter(c->c.getProductCategory().equals(category))
				 .collect(Collectors.toList());
				
			 if(productList.isEmpty()) {
				return "Product Not Found";
			    }
		return products;
	}

}*/
public Object getProducts() {
		
		return productRepository.findAll();
	}


public Object addProduct(Product product) {
	logger.info(product.toString());
	productRepository.save(product);
  logger.info("product added Successfully");
	return new ResponseEntity<>("Product added Successfully",HttpStatus.CREATED);
}
public Object getProductById(int id) {
	
	return productRepository.findById(id);

}

public Object getProductByCategory(String category) {
	
	return productRepository.findByCategory(category);

}

public Object updateProduct(Product product) {
	
	JsonObject response =new JsonObject();
	System.out.println("Request products:" + product);
	int id = product.getId();
    try {
	Product prod = productRepository.getOne(id);
	System.out.println("Request product :" + prod);

	System.out.println("old product:" + prod);
	prod.setPrice(product.getPrice());
	System.out.println("New product:" + prod);
	productRepository.save(prod);
    }
    catch(Exception e) {
    	logger.error(e.getMessage());
    	response.addProperty("statusCode", 404);
    	response.addProperty("statusMessage", e.getMessage());
    	return new ResponseEntity<>(response.toString(),HttpStatus.NOT_FOUND);
    }
    
    logger.info("Product Updated Successfully");
	return new ResponseEntity<>("Product Updated Successfully",HttpStatus.OK);
     	}


public Object deleteProduct(int id) {
	try {
		
	productRepository.deleteById(id);
	}catch(Exception e) {
			logger.error(e.getMessage());
			return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
	}
	
    logger.info("product deleted Successfully");
    return new ResponseEntity<>("Product Deleted Successfully",HttpStatus.OK);
}

public Object getProductPrice(float price) {
	//try {
		productRepository.findByPrice(price);
//}catch(Exception e) {
//			logger.error(e.getMessage());
	//		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
			return productRepository.findByPrice(price);
	}
 //logger.info("product get Successfully");
// return new ResponseEntity<>("Product Get Successfully By Price",HttpStatus.OK);
//}
	

public Object getProductByPriceAndCategory(float price, String category) {
	return productRepository.findByPriceAndCategory(price, category);
}

public Object getProductPriceByRange(float min, float max) {
	  return productRepository.findByPriceBetween(min, max);
		
	}

public Object getProductPriceByRangeAndCategory(float min, float max, String category) {
	  return productRepository.findByPriceBetweenAndCategory(min, max,category);
		
	}

}