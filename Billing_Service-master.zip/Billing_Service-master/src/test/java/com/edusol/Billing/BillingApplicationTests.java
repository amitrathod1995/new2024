package com.edusol.Billing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;

@SpringBootTest
@EnableHystrix
class BillingApplicationTests {

	@Test
	void contextLoads() {
	}

}
