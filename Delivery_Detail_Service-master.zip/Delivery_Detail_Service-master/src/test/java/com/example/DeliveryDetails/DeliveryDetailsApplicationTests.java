package com.example.DeliveryDetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliveryDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
