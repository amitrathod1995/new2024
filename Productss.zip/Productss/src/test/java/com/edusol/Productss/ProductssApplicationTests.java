package com.edusol.Productss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductssApplicationTests {

	@Test
	void contextLoads() {
	}

}
